package com.pratilipi.hotel;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HotelDetailsMicroserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(HotelDetailsMicroserviceApplication.class, args);
	}

}
