package com.pratilipi.hotel;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RoomManagerMicroserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
