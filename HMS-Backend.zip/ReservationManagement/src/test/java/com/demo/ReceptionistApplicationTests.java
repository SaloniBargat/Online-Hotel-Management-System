package com.demo;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import com.saloni.model.Guest;
import com.saloni.repository.GuestRepo;
import com.saloni.service.Guestservice;


@RunWith(SpringRunner.class)
@SpringBootTest
class ReceptionistApplicationTests {

	@Autowired
	Guestservice service;
//
	@MockBean
	private GuestRepo repo;

	@Test
	void contextLoads() {
	
	}
	@Test
	public void getGuestTest() {
		//This sets up a mock behavior for the findAll() method of a repository object (repo)
		when(repo.findAll())
		//It uses a stream of Guest objects to simulate the data returned by the repository. In this case, two Guest objects are created and added to the stream.
				.thenReturn(Stream
						.of(new Guest(100, "shiva",9876543, "shiva@gmail.com", "male", "hyd"),
								new Guest(100, "shiva",9876543, "shiva@gmail.com", "male", "hyd"))
						.collect(Collectors.toList()));
		 //This line verifies the behavior of the getAllGuest() method of the service class (service).
		//It checks if the size of the list returned by getAllGuest() is equal to 2 using the assertEquals() method from the testing framework.
		assertEquals(2, service.getAllGuest().size());
	}
	
	
	  @Test public void addGuestTest() { Guest guest = new Guest(100, "shiva",9876543, "shiva@gmail.com", "male", "hyd");
	  when(repo.insert(guest)).thenReturn(guest); assertEquals(guest,
	  service.addGuest(guest)); }
	 
	 
	
	
	@Test
	public void updateGuestTest() {
	Guest guest = new Guest(100, "shiva", 9876543, "shiva@gmail.com", "male", "hyd");
	when(repo.save(guest)).thenReturn(guest); 
	assertEquals(guest,service.updateGuest(guest));
	}
	
	
	
	
	@Test
	public Guest deleteGuestTest() {
	Guest guest=new Guest(100, "shiva", 9876543, "shiva@gmail.com", "male", "hyd");
	service.deleteGuest(1);
	verify(repo,times(1)).delete(guest);
	return guest;
	}
	 
}