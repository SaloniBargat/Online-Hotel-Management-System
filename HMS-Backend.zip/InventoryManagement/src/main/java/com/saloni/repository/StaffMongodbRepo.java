package com.saloni.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.saloni.model.Staff;



public interface StaffMongodbRepo extends MongoRepository<Staff, Long> {

}
