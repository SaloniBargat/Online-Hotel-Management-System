package com.saloni.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.saloni.model.ManagerInformation;


public interface ManagerRepository extends MongoRepository<ManagerInformation , String> {
	
	ManagerInformation findByEmail(String email);

}