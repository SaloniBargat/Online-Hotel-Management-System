package com.saloni.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.saloni.model.Owner;



public interface OwnerRepository extends MongoRepository<Owner , Integer> {
	
}
