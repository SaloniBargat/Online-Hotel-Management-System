package com.saloni.jwtmodels;

import java.io.Serializable;

//public class AuthenticationResponse implements Serializable {
//
//    private final String jwt;
//
//    public AuthenticationResponse(String jwt) {
//        this.jwt = jwt;
//    }
//
//    public String getJwt() {
//        return jwt;
//    }
//}
public class AuthenticationResponse{ /*
* private String response;
*
* public AuthenticationResponse() {
*
* }
*
* public AuthenticationResponse(String response) { super(); this.response =
* response; }
*
* public String getResponse() { return response; }
*
* public void setResponse(String response) { this.response = response; }
*/
}

